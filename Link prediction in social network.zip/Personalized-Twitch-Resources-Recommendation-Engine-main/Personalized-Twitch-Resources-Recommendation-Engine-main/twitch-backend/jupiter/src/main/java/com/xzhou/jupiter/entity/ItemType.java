package com.xzhou.jupiter.entity;

public enum ItemType {
    STREAM, VIDEO, CLIP;

}
